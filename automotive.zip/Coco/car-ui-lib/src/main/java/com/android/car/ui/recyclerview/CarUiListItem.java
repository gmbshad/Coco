package com.android.car.ui.recyclerview;

/**
 * All items that can be inserted into {@link CarUiListItemAdapter} must extend this class.
 */
public abstract class CarUiListItem {
}

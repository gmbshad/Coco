package dz.islem.automotive.util

enum class FuelType {
    UNKNOWN,UNLEADED,LEADED,DIESEL_1,DIESEL_2,BIODIESEL,E85,LPG,CNG,LNG,ELECTRIC,
    HYDROGEN,OTHER
}